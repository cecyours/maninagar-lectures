import Student_protected.*;

public class CH08_T02_Protected_Keyword {
    public static void main(String[] args) {
        CH08_T03_PROTECTED p = new CH08_T03_PROTECTED();
        
        p.display();
    }
}

